package com.example.tour_nest.model.tour;

public class Photo {
    private String imageUrl;

    public Photo(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}
