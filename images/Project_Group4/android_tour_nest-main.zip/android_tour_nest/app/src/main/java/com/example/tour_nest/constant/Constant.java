package com.example.tour_nest.constant;

public class Constant {
    public static int USER_ROLE = 1;
    public static int ADMIN_ROLE = 0;
}
